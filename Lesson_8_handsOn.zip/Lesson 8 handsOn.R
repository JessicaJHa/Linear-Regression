View(mtcars)

#we are going to examine the effect of horsepower and veicle weight on the time necessary to travel a quarter mile from a standing start
#scatter plot with engine horsepower and qarter mile time

library("ggplot2")
ggplot(data=mtcars, aes(x = hp, y = qsec)) + geom_point() + geom_smooth(method='lm', se = TRUE)

# the graph is negatively correlated as the dots and line show it start high on the left, and goes down to the bottom right

#compute the linear regression for engine horsepower and quarter mile time

regression <- lm(qsec~hp, mtcars)
summary(regression)

# the equation of the line is y= -0.02x + 20.56
#The R squared value is .49, meaning that horsepower explains 49% of the varience in the quarter mile time.
#This is what we would expect to see, the more horsepower, the more powerful the engine and the faster the car should be able to go.

#Scatter plot with vehicle weight and quarter mile time

library("ggplot2")
ggplot(data=mtcars, aes(x = wt, y = qsec)) + geom_point() + geom_smooth(method= lm, se= TRUE)

#the graph is uncorrelated.

#Compute the linear regression for vehicle weight and quarter mile time
regression2 <- lm(qsec~wt, mtcars)
summary(regression2)

#the equation of the line is: y = -.32x + 18.88
#the R squared value is -.00, which means that the vehicle weight does not account for any of the variance in quarter mile time


#The weights don't seem to vary enough in this data set. 






